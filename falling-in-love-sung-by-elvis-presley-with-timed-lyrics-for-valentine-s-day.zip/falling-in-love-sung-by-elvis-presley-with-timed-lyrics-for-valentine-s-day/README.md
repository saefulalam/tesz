# "Falling in Love"  sung by Elvis Presley with timed Lyrics for Valentine's Day

A Pen created on CodePen.

Original URL: [https://codepen.io/mark_sottek/pen/vLbvXB](https://codepen.io/mark_sottek/pen/vLbvXB).

Experiment with the audio element timing function and a last minute valentine for my boo.of thirty years .  I've been playing around with the idea of synching stuff on a users screen to audio.  Simply added an event listener and used jQuery to toggle classes to synch the lyrics to the audio timeline.  Animated hearts inspired and forked from Gerard Ferrandez -  http://codepen.io/ge1doot/pen/OypQdy